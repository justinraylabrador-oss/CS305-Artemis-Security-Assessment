package com.snhu.artemis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtemisFinancialApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArtemisFinancialApplication.class, args);
    }

}