package com.snhu.artemis;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;

@RestController
public class ArtemisFinancialController {

    // SHA-256 Hash Method
    public static String calculateHash(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
            BigInteger number = new BigInteger(1, hash);
            StringBuilder hexString = new StringBuilder(number.toString(16));

            while (hexString.length() < 64) {
                hexString.insert(0, '0');
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Secure HTTPS Endpoint
    @GetMapping("/hash")
    public String displayHash() {

        String uniqueData = "Justin-CS305-2026";  // CHANGE THIS
        String checksum = calculateHash(uniqueData);

        return "<h1>Artemis Financial Secure Hash</h1>" +
                "<p>Data: " + uniqueData + "</p>" +
                "<p>SHA-256 Checksum: " + checksum + "</p>";
    }
}